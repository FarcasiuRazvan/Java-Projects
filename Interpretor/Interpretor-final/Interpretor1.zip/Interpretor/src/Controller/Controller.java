package Controller;

import Model.*;
import Repository.*;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Controller {
    private IPrgRepo repo;

    public Controller(IPrgRepo newrepo) {
        this.repo = newrepo;
    }

    private HashMap<Integer,Integer> conservativeGarbageCollector(Collection<Integer> symTableValues, Map<Integer,Integer> heap)
    {
        Map<Integer,Integer> map=heap.entrySet().stream()
                .filter(e->symTableValues.contains(e.getKey()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        HashMap<Integer,Integer> hashMap= new HashMap<>();
        for(Integer key : map.keySet())
            hashMap.put(key,map.get(key));
        return hashMap;
    }


    public void allStep() throws MyException, IOException {
        PrgState prgState = repo.getCrtPrg();

        while (!prgState.getStk().isEmpty()) {
            executeOneStatement(prgState);
            prgState.getHeap().setHeap(this.conservativeGarbageCollector(prgState.getSymTable().getContent().values(), prgState.getHeap().getHeap()));
            repo.logPrgStateExec();
        }



        System.out.println("-----ProgramStateStart------");
        System.out.println(prgState.toString());
        System.out.println("-----ProgramStateEnd------");
    }
    private void executeOneStatement(PrgState prg) throws MyException
    {
        MyIStack<IStmt> execStack = prg.getStk();

        if (!execStack.isEmpty()) {
            IStmt statement = execStack.pop();
            try {
                statement.execute(prg);
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.print("Execution stack: ");
            System.out.println(execStack.toString());//.toStr());
            System.out.print("Symbol Table: ");
            System.out.println(prg.getSymTable().toString());
            System.out.print("Output: ");
            System.out.println(prg.getOutput().toString());
            System.out.print("FileTable: ");
            System.out.println(prg.getFileTable().toString());
            System.out.println("\n ==> \n");
        }
    }
}
