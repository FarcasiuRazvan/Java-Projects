package Model;

import java.io.BufferedReader;

public class PrgState {
    private MyIStack<IStmt> exeStack;
    private MyIDictionary<String,Integer> symTable;
    private MyIList<Integer> out;
    private MyIFileTable<Integer, Pair<String,BufferedReader>> fileTable;
    private MyIHeap<Integer,Integer> heap;
    private IStmt originalProgram;

    public PrgState(MyIStack<IStmt> stk, MyIDictionary<String,Integer> symtbl, MyIList<Integer> ot,MyIFileTable<Integer,Pair<String,BufferedReader>> fTable,MyIHeap<Integer,Integer> heap1 ,IStmt prg)
    {
        this.exeStack=stk;
        this.symTable=symtbl;
        this.out=ot;
        this.fileTable=fTable;
        this.heap=heap1;
        this.exeStack.push(prg);
    }

    public MyIStack<IStmt> getStk()
    {
        return this.exeStack;
    }
    public MyIFileTable<Integer,Pair<String,BufferedReader>> getFileTable()
    {
        return this.fileTable;
    }

    public MyIDictionary<String,Integer> getSymTable()
    {
        return this.symTable;
    }

    public MyIList<Integer> getOutput(){return this.out;}
    public MyIHeap<Integer,Integer> getHeap(){return this.heap;}
    public String toString()
    {
        return this.exeStack.toString()+"@"+ this.symTable.toString()+"@"+this.out.toString()+"@"+this.fileTable.toString()+"@"+this.heap.toString();
    }
}
