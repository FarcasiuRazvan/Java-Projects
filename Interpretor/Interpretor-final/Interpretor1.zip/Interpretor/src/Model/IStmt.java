package Model;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface IStmt {
    String toString();
    void execute(PrgState state) throws MyException, IOException;
}
