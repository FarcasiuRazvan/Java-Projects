package Repository;

import Model.PrgState;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Vector;

public class PrgRepo implements IPrgRepo{
    private ArrayList<PrgState> programStates;
    private String logFilePath;

    public PrgRepo(String logFile)
    {
        this.programStates=new ArrayList<>();
        this.logFilePath=logFile;
    }

    public PrgState getCrtPrg()
    {
        return this.programStates.get(0);
    }

    public void add(PrgState pr)
    {
        this.programStates.add(pr);
    }

    public void logPrgStateExec() throws IOException {

        BufferedWriter buff=new BufferedWriter(new FileWriter(this.logFilePath, true));
        PrintWriter logFile = new PrintWriter(buff);
        String[] fileString=getCrtPrg().toString().split("@");
        String[] execStack=fileString[0].split("#");
        String[] symbolTable=fileString[1].split("#");
        String[] Output=fileString[2].split("#");
        String[] fileTable=fileString[3].split("#");
        String[] heap=fileString[4].split("#");


        logFile.print("EXECUTION STACK");
        buff.newLine();
        for(int i=0;i<execStack.length;i++) {
            logFile.print(execStack[i]);
            buff.newLine();
        }

        logFile.print("SYMBOL TABLE");
        buff.newLine();
        for(int i=0;i<symbolTable.length;i++) {
            logFile.print(symbolTable[i]);
            buff.newLine();
        }

        logFile.print("OUTPUT");
        buff.newLine();
        for(int i=0;i<Output.length;i++) {
            logFile.print(Output[i]);
            buff.newLine();
        }

        logFile.print("FILETABLE");
        buff.newLine();
        for(int i=0;i<fileTable.length;i++) {
            logFile.print(fileTable[i]);
            buff.newLine();
        }

        logFile.print("HEAP");
        buff.newLine();
        for(int i=0;i<heap.length;i++) {
            logFile.print(heap[i]);
            buff.newLine();
        }

        buff.newLine();
        buff.newLine();
        buff.newLine();
        logFile.close();

    }

}

