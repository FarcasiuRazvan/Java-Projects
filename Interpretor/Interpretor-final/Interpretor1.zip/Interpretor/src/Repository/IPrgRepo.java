package Repository;

import Model.PrgState;

import java.io.IOException;

public interface IPrgRepo {
    PrgState getCrtPrg();
    void add(PrgState pr);
    void logPrgStateExec() throws IOException;
}
